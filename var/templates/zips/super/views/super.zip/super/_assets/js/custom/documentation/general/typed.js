"use strict";var KTGeneralTypedJsDemos={init:function(){new Typed("#kt_typedjs_example_1",{strings:["First sentence.","Second sentence.","Third sentense","And some longer sentence"],typeSpeed:30})}};KTUtil.onDOMContentLoaded((function(){KTGeneralTypedJsDemos.init()}));
//# sourceMappingURL=typed.js.map
