let body = $('body');

/**
 * valid with general options
 * must use in top of files
 */
let generalValidation = function (form_id, submit_id, locale) {
    let form = document.querySelector(form_id);
    let button_submit = document.querySelector(submit_id);
    let locale_name = '';
    let form_locale = '';
    if (locale === 'ar') {
        locale_name = 'ar_MA';
        form_locale = FormValidation.locales.ar_MA;
    }

    let valid_result = FormValidation.formValidation(form, {
        locale: locale_name, localization: form_locale, plugins: {
            trigger: new FormValidation.plugins.Trigger, bootstrap: new FormValidation.plugins.Bootstrap5({rowSelector: ".fv-row"}), declarative: new FormValidation.plugins.Declarative({
                html5Input: true
            })
        }
    });
    button_submit.addEventListener("click", (function (n) {
        n.preventDefault();
        valid_result.validate().then((function (result) {
            if (result === 'Valid') {
                form.submit()
            } else {
                Swal.fire({
                    text: "Sorry, looks like there are some errors detected, please try again.",
                    icon: "error",
                    buttonsStyling: !1,
                    confirmButtonText: "Ok, got it!",
                    customClass: {confirmButton: "btn btn-primary"}
                });
            }
        }));
    }));
}

/**
 * create jquery validation
 */
$(document).ready(function () {
    $('.fv-form').validate();

    let request_bag_alert = $('#request_bag_alert');
    let request_bag_alert_val = request_bag_alert.val();
    let data_parse;
    if (request_bag_alert_val.length) {
        data_parse = JSON.parse(request_bag_alert.val());
        Swal.fire(_t['messages_box.finish_dialog.' + data_parse.status + ''], data_parse.message, data_parse.status);
    }

    body.on('click', '.locale-subscribe', function () {
        let _locale = $(this).attr('data-prefix');
        axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
        axios.post(appUrl + 'super/locale-subscribe', {_locale: _locale}).then(function () {
            location.reload();
        });
    });

    body.on('click', '.theme-style-subscribe', function () {
        let _theme_style = $(this).attr('data-theme');
        axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
        axios.post(appUrl + 'super/theme-style-subscribe', {_theme_style: _theme_style}).then(function () {
            location.reload();
        });
    });
});

/**
 * Delete selected on table
 */
let deleteSelected = function () {

    $(document).ready(function () {
        body.on('click', '.remove-selected', function () {
            let selected_items = $('.remove-selected-item:checkbox:checked:not(:disabled)');
            let control_slug = $(this).attr('data-control');
            let action_slug = $(this).attr('data-action');
            let _ion_token = $('#_ion_token').val();
            if (selected_items.length > 0) {
                Swal.fire({
                    text: _t['messages_box.delete_dialog_select.confirm.text'],
                    icon: "error",
                    showCancelButton: !0,
                    buttonsStyling: !1,
                    confirmButtonText: _t['messages_box.delete_dialog_select.confirm.confirm_btn'],
                    cancelButtonText: _t['messages_box.delete_dialog_select.confirm.cancel_btn'],
                    customClass: {confirmButton: "btn fw-bold btn-danger", cancelButton: "btn fw-bold btn-active-light-primary"},
                    showLoaderOnConfirm: true,
                }).then((function (n) {
                    if (n.value) {
                        let selected_items_ids = '';
                        selected_items.each(function () {
                            let check_id = $(this).val();
                            selected_items_ids += ',' + check_id;
                        })
                        selected_items_ids = selected_items_ids.substring(1);
                        axios.post(appUrl + control_slug + '/' + action_slug, {ids: selected_items_ids, type: 'multi', _ion_token: _ion_token})
                            .then(function (response) {
                                deleteHasResponse(response);
                            })
                            .catch(function (error) {
                                deleteHasError(error);
                            });
                    }
                }))

            } else {
                Swal.fire({
                    text: _t['messages_box.delete_dialog_select.non_selected.text'],
                    icon: "warning",
                    showCancelButton: 0,
                    buttonsStyling: !1,
                    showLoaderOnConfirm: 0,
                    confirmButtonText: _t['messages_box.delete_dialog_select.non_selected.confirm_btn'],
                    customClass: {confirmButton: "btn fw-bold btn-danger"}
                })
            }

        });
    });

    function deleteHasResponse(response) {
        if (response.data.status === true) {
            Swal.fire(_t['messages_box.delete_dialog.deleted.title'], _t['messages_box.delete_dialog.deleted.content'], "success").then(() => {
                location.reload();
            });
        } else {
            Swal.fire(_t['messages_box.delete_dialog.deleted.title'], _t['messages_box.delete_dialog.deleted.content_error'] + ': ' + response.data.message, "error")
                .then(() => {
                    location.reload();
                });
        }
    }

    function deleteHasError(error) {
        let res = JSON.parse(error.request.response);
        if (res.message) {
            Swal.fire(_t['messages_box.delete_dialog.deleted.title'],
                _t['messages_box.delete_dialog.deleted.content_error'] + ': ' + (IsJsonString(res.message) ? JSON.parse(res.message)[0] : res.message), "error");
        } else {
            Swal.fire(_t['messages_box.delete_dialog.deleted.title'] + '', _t['error.access_deny'], "error");
        }
    }

    body.on('click', '.delete_item', function () {
        let this_item = $(this);
        let element_id = this_item.attr('data-id');
        let control_link = this_item.attr('data-link');
        let action_link = this_item.attr('data-action');
        let _ion_token = $('#_ion_token').val();
        Swal.fire({
            title: _t['messages_box.delete_dialog.title'],
            text: _t['messages_box.delete_dialog.content'],
            icon: "error",
            showCancelButton: true,
            confirmButtonText: _t['messages_box.delete_dialog.approve_btn'],
            cancelButtonText: _t['messages_box.delete_dialog.cancel_btn'],
            customClass: {confirmButton: "btn fw-bold btn-danger", cancelButton: "btn fw-bold btn-active-light-primary"},
        }).then(function (result) {
            if (result.value) {
                axios.post(appUrl + control_link + '/' + action_link, {id: element_id, _ion_token: _ion_token})
                    .then(function (response) {
                        deleteHasResponse(response);
                    })
                    .catch(function (error) {
                        deleteHasError(error);
                    });
            }
        });
    });
}
deleteSelected();

/**
 *  create instance of datatable
 *  normal call
 */
let datatableCall = function (lang) {

    // Shared variables
    const table = $("#ion_tbl_dt");

    if (table.length) {
        let dt;
        dt = table.DataTable({
            responsive: false, searchDelay: 500, processing: false, serverSide: false, lengthMenu: [[15, 25, 50, 100, 200, -1], [15, 25, 50, 100, 200, 'All']], pageLength: 25, "language": {
                "url": lang === 'ar' ? htmlUrl + "/plugins/custom/datatables/Arabic.json" : ''
            },
        });

        dtOptions(dt, table);
    }

}

function dtOptions(dt, table) {

    dt.on('draw', function () {
        KTMenu.createInstances();
    });

    const filterSearch = document.querySelector('[data-kt-docs-table-filter="search"]');
    filterSearch.addEventListener('keyup', function (e) {
        dt.search(e.target.value).draw();
    });

    const report_btn_title = _t['titles.dt.export_report_title'] + ' ' + controlName;
    new $.fn.dataTable.Buttons(table, {
        buttons: [{
            extend: "copyHtml5", title: report_btn_title, exportOptions: {
                columns: ':visible:not(.not-export-col)'
            }
        }, {
            extend: "excelHtml5", title: report_btn_title, exportOptions: {
                columns: ':visible:not(.not-export-col)'
            }
        }, {
            extend: "csvHtml5", title: report_btn_title, exportOptions: {
                columns: ':visible:not(.not-export-col)'
            }
        }, {
            extend: "pdfHtml5", title: report_btn_title, exportData: {decodeEntities: false}, exportOptions: {
                columns: ':visible:not(.not-export-col)'
            }
        }]
    }).container().appendTo($("#ion_tbl_dt_views_export"));
    document.querySelectorAll("#ion_tbl_dt_views_export_menu [data-kt-dt-export]").forEach((item => {
        item.addEventListener("click", (inner_item => {
            inner_item.preventDefault();
            const attribute = inner_item.target.getAttribute("data-kt-dt-export");
            document.querySelector(".dt-buttons .buttons-" + attribute).click()
        }))
    }))
}

/**
 *  create instance of datatable ajax
 *  server side call
 */
let datatableServerCall = function (lang) {

    // Shared variables
    const table = $("#ion_tbl_dt_ajax");

    if (table.length) {
        let dt;
        let data_source = table.attr('data-source');
        dt = table.DataTable({
            responsive: false, searchDelay: 500, processing: true, serverSide: true, lengthMenu: [[15, 25, 50, 100, 200, 500], [15, 25, 50, 100, 200, 500]], pageLength: 25, language: {
                "url": lang === 'ar' ? htmlUrl + "/plugins/custom/datatables/Arabic.json" : ''
            }, //stateSave: true,
            ajax: {
                url: data_source,//data_load,
                type: 'POST', data: {
                    //data_id_search: $('#data_id_search').val()
                }
            }, columns: $.parseJSON($('#ion_dtl_columns').html()),
        });

        table.on('change', '.group-check-able', function () {
            const set = $(this).closest('table').find('td:first-child .check-able');
            const checked = $(this).is(':checked');

            $(set).each(function () {
                if (checked) {
                    $(this).prop('checked', true);
                } else {
                    $(this).prop('checked', false);
                }
            });
        });

        dtOptions(dt, table);
    }
}

/**
 *
 * @param str
 * @returns {boolean}
 * @constructor
 */
function IsJsonString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

/**
 * create tree for controls
 * @param three_state
 */
let controlsTree = function (three_state = true) {
    let tree_id = $('#kt_docs_jstree_basic');
    tree_id.jstree({
        'plugins': ["checkbox", "types"], 'core': {
            "themes": {
                "responsive": false
            }
        }, "types": {
            "default": {
                "icon": "bi bi-menu-button-fill text-info"
            }, "file": {
                "icon": "bi bi-diagram-2-fill  text-primary"
            }
        }, "checkbox": {
            "keep_selected_style": true, "three_state": three_state, //"cascade": "undetermined",
        }
    }).bind('loaded.jstree', function () {
        $(this).jstree("open_all");
    });
    Array.prototype.unique = function () {
        return Array.from(new Set(this));
    }

    tree_id.on("changed.jstree", function (e, data) {
        let i, selected = [];
        for (i = 0; i < data.selected.length; i++) {
            selected = selected.concat(tree_id.jstree(true).get_path(data.selected[i], false, true));
        }
        selected = selected.unique();
        let x, j, controls = [], actions = [];
        for (x = 0, j = selected.length; x < j; x++) {
            let node_selected = $('#' + selected[x]);
            let id = node_selected.attr('data-id');
            let type = node_selected.attr('data-type');
            if (type === 'control') {
                controls.push(id);
            } else if (type === 'action') {
                actions.push(id);
            }
        }
        $('#ids_controls').val(controls.join(','));
        $('#ids_actions').val(actions.join(','));
    });

};

/**
 * nestable for controls
 * @param class_name
 * @param control_name
 * @private
 */
let _nestable_show = function (class_name, control_name) {
    let nestable_item = $(class_name);
    if (nestable_item.length <= 0) {
        return;
    }
    nestable_item.nestable({ /* config options */});
    nestable_item.on('change', function () {
        axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
        axios.post(appUrl + control_name + '/sortItems', {orderJson: window.JSON.stringify(nestable_item.nestable('serialize'))}).then(function (result) {
            if (result.data === 1) {
                Swal.fire(_t['control.sort_item.success_title'], _t['control.sort_item.success_content'], "success")
            } else {
                Swal.fire(_t['control.sort_item.error_title'], _t['control.sort_item.error_content'], "error");
            }
        });
    });
};

/**
 * action repeater
 */
let actionRepeater = function (is_empty = true) {
    $('#actions_container').repeater({
        initEmpty: is_empty, show: function () {
            $(this).attr('data-id', '');
            $(this).slideDown();
        }, hide: function (deleteElement) {
            let this_ele = $(this);
            Swal.fire({
                text: _t['control.actions.delete_dialog.text'],
                icon: "warning",
                buttonsStyling: false,
                showCancelButton: !0,
                confirmButtonText: _t['control.actions.delete_dialog.confirm'],
                cancelButtonText: _t['control.actions.delete_dialog.cancel'],
                customClass: {confirmButton: "btn fw-bold btn-danger", cancelButton: "btn fw-bold btn-active-light-primary"},
            }).then(function (n) {
                if (n.value) {
                    let action_id = this_ele.attr('data-id');
                    if (action_id > 0) {
                        axios.post(appUrl + 'super/control/deleteAction', {action_id: action_id}).then(function () {
                            this_ele.slideUp(deleteElement);
                        });
                    } else {
                        this_ele.slideUp(deleteElement);
                    }
                }
            });
        }
    });
};