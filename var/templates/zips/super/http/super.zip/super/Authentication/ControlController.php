<?php

namespace App\Http\super\Authentication;

use Ions\Auth\Guard\Control;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Arr;
use Ions\Support\JsonResponse;
use Ions\Support\Request;
use Ions\Support\Route;
use JetBrains\PhpStorm\NoReturn;
use JetBrains\PhpStorm\Pure;
use Throwable;

class ControlController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        $this->locale = appGetLocale();
        SharedData::accessApprove(['add' => 'save', 'edit' => 'update', 'index' => 'sortItems', 'destroy' => 'deleteAction']);
    }

    #[Pure] private function rules($type, $id = null): array
    {
        $rules = [
            'slug' => 'required|unique:controls,slug,' . $id,
            'name_ar' => 'required',
            'name_en' => 'required',
            'status' => 'required',
            'link' => 'required',
            'active_name' => 'required',
            'id' => 'required|numeric|not_in:0|exists:controls,id',
            'action_id' => 'required|numeric|not_in:0|exists:actions,id',
        ];
        return match ($type) {
            'store' => Arr::only($rules, ['slug', 'name_ar', 'name_en', 'status']),
            'update' => Arr::only($rules, ['slug', 'name_ar', 'name_en', 'status', 'id']),
            'single', 'delete' => Arr::only($rules, ['id']),
            'deleteAction' => Arr::only($rules, ['action_id']),
            default => $rules,
        };
    }

    #[Route('/super/control/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {
        $controls = Control::hierarchy($this->locale);
        $this->twig->display($this->view_folder . '_Authentication/control/show.html.twig', ['controls' => $controls]);
    }

    #[Route('/super/control/sortItems', methods: 'post')]
    public function sortItems(Request $request): void
    {
        $orderJson = $request->get('orderJson');

        try {
            Control::order($orderJson);
            echo true;
        } catch (Throwable) {
            echo false;
        }
    }

    #[Route('/super/control/add')]
    public function add(Request $request): void
    {
        $parents = Control::all($this->locale);
        $this->twig->display($this->view_folder . '_Authentication/control/add.html.twig',
            $request->get('forwards', []) + $request->all() + ['parents' => $parents]
        );
    }

    #[Route('/super/control/save', methods: 'post')]
    public function save(Request $request): void
    {
        $valid = csrfCheck('control_add');
        if (!$valid) {
            Redirect::internal('super/control/add');
        }

        $result = validate($request->all(), $this->rules('store'));
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->add($request);
            exit();
        }

        $params = [
            'slug' => $request->get('slug'),
            'parent_id' => $request->get('parent_id'),
            'status' => $request->get('status'),
            'icon' => $request->get('icon'),
            'link' => $request->get('link'),
            'active_name' => $request->get('active_name'),
            'is_tag' => $request->get('is_tag'),
            'languages' => [
                ['language_name' => 'ar', 'name' => $request->get('name_ar')],
                ['language_name' => 'en', 'name' => $request->get('name_en')],
            ],
            'actions' => []
        ];

        foreach ($request->get('actions_container', []) as $action) {
            $params['actions'][] = [
                'slug' => $action['action_slug'],
                'status' => $action['action_status'],
                'languages' => [
                    ['language_name' => 'ar', 'action_name' => $action['action_name_ar']],
                    ['language_name' => 'en', 'action_name' => $action['action_name_en']],
                ]
            ];
        }
        try {
            $params = json_decode(json_encode($params, JSON_THROW_ON_ERROR), false, 512, JSON_THROW_ON_ERROR);
            Control::add($params);

            $this->session->set('request_bag', ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_message')]);
            Redirect::internal('super/control');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->add($request);
            exit();
        }
    }

    #[Route('/super/control/edit/{id}')]
    public function edit(Request $request): void
    {
        $result = validate(['id' => $request->get('id')], $this->rules('single'));
        if (!empty($result)) {
            Redirect::internal('super/control');
        }

        $id = $request->get('id');
        $parents = Control::all($this->locale, $id);
        $control = Control::single($id);
        $this->twig->display($this->view_folder . '_Authentication/control/edit.html.twig',
            $request->get('forwards', []) + ['control' => $control, 'parents' => $parents]
        );
    }

    #[Route('/super/control/update', methods: 'post')]
    public function update(Request $request): void
    {
        $id = $request->get('id');

        $valid = csrfCheck('control_edit');
        if (!$valid) {
            Redirect::internal('super/control/edit/' . $id);
        }

        $result = validate($request->all(), $this->rules('update', $id));
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->edit($request);
            exit();
        }

        $params = [
            'id' => $request->get('id'),
            'slug' => $request->get('slug'),
            'parent_id' => $request->get('parent_id'),
            'status' => $request->get('status'),
            'icon' => $request->get('icon'),
            'link' => $request->get('link'),
            'active_name' => $request->get('active_name'),
            'is_tag' => $request->get('is_tag'),
            'languages' => [
                ['language_id' => $request->get('name_ar_id'), 'language_name' => 'ar', 'name' => $request->get('name_ar')],
                ['language_id' => $request->get('name_en_id'), 'language_name' => 'en', 'name' => $request->get('name_en')],
            ],
            'actions' => []
        ];

        foreach ($request->get('actions_container', []) as $action) {
            $params['actions'][] = [
                'action_id' => $action['action_id'],
                'slug' => $action['action_slug'],
                'status' => $action['action_status'],
                'languages' => [
                    ['action_language_id' => $action['action_id_ar'], 'language_name' => 'ar', 'action_name' => $action['action_name_ar']],
                    ['action_language_id' => $action['action_id_en'], 'language_name' => 'en', 'action_name' => $action['action_name_en']],
                ]
            ];
        }
        try {
            $params = json_decode(json_encode($params, JSON_THROW_ON_ERROR), false, 512, JSON_THROW_ON_ERROR);
            Control::update($params);
            $this->session->set('request_bag', ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_edit_message')]);

            Redirect::internal('super/control');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->edit($request);
            exit();
        }
    }

    #[NoReturn] #[Route('/super/control/delete')]
    public function destroy(Request $request): void
    {
        $valid = csrfCheck('control_show');
        if (!$valid) {
            echo toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]);
            exit();
        }
        $result = validate(['id' => $request->get('id')], $this->rules('delete'));
        if (!empty($result)) {
            echo toJson(['status' => false, 'message' => $result]);
            exit();
        }
        $id = $request->get('id');
        if (!Control::delete($id)) {
            echo toJson(['status' => false, 'message' => trans('messages_box.delete_error')]);
            exit();
        }
        echo toJson(['status' => true, 'message' => '']);
        exit();
    }

    #[NoReturn] #[Route('/super/control/deleteAction')]
    public function deleteAction(Request $request): void
    {
        $result = validate(['action_id' => $request->get('action_id')], $this->rules('deleteAction'));
        if (!empty($result)) {
            echo toJson(['status' => false, 'message' => $result]);
            exit();
        }
        $id = $request->get('action_id');
        if (!Control::deleteAction($id)) {
            echo toJson(['status' => false, 'message' => $id]);
            exit();
        }
        echo toJson(['status' => true, 'message' => '']);
        exit();
    }
}
