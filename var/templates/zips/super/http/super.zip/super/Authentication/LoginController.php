<?php

namespace App\Http\super\Authentication;

use Ions\Auth\Guard\Guard;
use Ions\Auth\Guard\User;
use Ions\Bundles\Path;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Request;
use Ions\Support\Route;
use Ions\Support\Storage;
use Ions\Support\Str;
use JetBrains\PhpStorm\NoReturn;
use Throwable;

class LoginController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';
    
    #[Route('/super/login/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(Request $request): void
    {
        if (Guard::check()) {
            Redirect::internal('super/index');
        }
        $this->twig->display($this->view_folder.'_Authentication/login/login.html.twig', $request->get('forwards', []));
    }

    #[NoReturn] #[Route('/super/login/lg', methods: 'post')]
    public function lg(Request $request): void
    {
        $valid = csrfCheck('login');
        if (!$valid) {
            Redirect::internal('super/login');
        }

        $input_request = $request->all();

        $result = validate($input_request, ['login' => 'required', 'password' => 'required|min:6']);
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->index($request);
            exit();
        }

        $is_login = Guard::login([
            'login' => $request->get('login'),
            'password' => $request->get('password')
        ], (bool)$request->get('remember_me', false));

        if ($is_login === true) {
            Redirect::internal('super/index');
        }

        $request->attributes->set('forwards', ['error_message' =>
            trans('login.error_logins.' . $is_login['error'])
        ]);
        $this->index($request);
        exit();
    }

    #[Route('/super/logout')]
    public function logout(): void
    {
        if (Guard::logout()) {
            Redirect::internal('super/login');
        }
    }

    #[Route('/super/login/register')]
    public function register(Request $request): void
    {
        if (Guard::check()) {
            Redirect::internal('super/index');
        }

        $this->twig->display($this->view_folder.'_Authentication/login/register.html.twig',
            $request->get('forwards', []) + $request->all()
        );
    }

    #[Route('/super/login/rg', methods: 'post')]
    public function rg(Request $request): void
    {
        $valid = csrfCheck('register');
        if (!$valid) {
            Redirect::internal('super/login/register');
        }

        $result = validate($request->all(), [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|unique:users,email',
            'mobile' => 'required|unique:users,mobile',
            'password' => 'required|confirmed|min:6'
        ]);
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->register($request);
            exit();
        }

        try {
            User::add((object)[
                'email' => $request->get('email'),
                'first_name' => $request->get('first_name'),
                'last_name' => $request->get('last_name'),
                'status' => 1,
                'mobile' => $request->get('mobile'),
                'password' => $request->get('password'),
                'role_id' => 1 // must be guest role
            ]);

            Redirect::internal('super/login');
        } catch (Throwable $e) {
            $request->attributes->set('forwards', ['error_message' => trans('register.error_register.fail_register') . $e->getMessage()]);
            $this->register($request);
            exit();
        }
    }

    #[Route('/super/login/forget')]
    public function forget(Request $request): void
    {
        if (Guard::check()) {
            Redirect::internal('super/index');
        }

        $this->twig->display($this->view_folder.'_Authentication/login/forget.html.twig', $request->get('forwards', []));
    }

    #[NoReturn] #[Route('/super/login/forgot', methods: 'post')]
    public function forgot(Request $request): void
    {
        $valid = csrfCheck('forget');
        if (!$valid) {
            Redirect::internal('super/login/forget');
        }

        $email = $request->get('email');

        $result = validate(['email' => $email], ['email' => 'required|email|exists:users,email']);
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->forget($request);
            exit();
        }

        $forget_code = Guard::forgetCode(['email' => $email]);

        if (!empty($forget_code)) {
            $reset_link = Path::root('super/login/reset?reset_key=' . $forget_code, true);

            $body = Str::replace(['{{ reset_link }}'], [$reset_link], Storage::get(Path::templates('Emails/forget_password.html')));
            $subject = 'Reset your password';

            if(newMailerDsn($email,$subject,$body)){
                Redirect::internal('super/login');
            }

            $request->attributes->set('forwards', ['error_message' => trans('forget.error_forget.mail_fail')]);
            $this->forget($request);
            exit();
        }

        $request->attributes->set('forwards', ['error_message' => trans('forget.error_forget.wrong_code')]);
        $this->forget($request);
        exit();
    }

    #[Route('/super/login/reset')]
    public function reset(Request $request): void
    {
        if (Guard::check()) {
            Redirect::internal('super/index');
        }

        $code = $request->get('reset_key');
        $user = Guard::checkResetCode($code);
        if (!$code || empty($user)) {
            Redirect::internal('super/login');
        }

        $this->twig->display($this->view_folder.'_Authentication/login/reset.html.twig', [
                'code' => $code, 'reset_user_id' => $user->user_id
            ] + $request->get('forwards', []));
    }

    #[NoReturn] #[Route('/super/login/resetIt', methods: 'post')]
    public function resetIt(Request $request): void
    {
        $valid = csrfCheck('reset');
        if (!$valid) {
            Redirect::internal('super/login');
        }

        $key = $request->get('reset_key');
        $password = $request->get('password');
        $user_id = $request->get('user_id');

        $result = validate($request->all(), [
            'reset_key' => 'required|exists:reminders,code',
            'password' => 'required_if:old_password,null|confirmed|min:6',
            'user_id' => 'required|numeric']);
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->reset($request);
            exit();
        }

        $finish = Guard::completeReset($user_id, $key, $password);

        if (!$finish) {
            $request->attributes->set('forwards', ['error_message' => trans('reset.error_reset.fail_reset')]);
            $this->reset($request);
            exit();
        }

        Redirect::internal('super/login');
    }
}
