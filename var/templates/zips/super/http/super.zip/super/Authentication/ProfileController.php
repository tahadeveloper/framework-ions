<?php

namespace App\Http\super\Authentication;

use Ions\Auth\Guard\Guard;
use Ions\Auth\Guard\User;
use Ions\Bundles\IonUpload;
use Ions\Bundles\Path;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Arr;
use Ions\Support\Request;
use Ions\Support\Route;
use JetBrains\PhpStorm\Pure;
use Throwable;

class ProfileController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
    }

    #[Pure] private function rules($type, $id = null): array
    {
        $rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'emails' => 'required|email|unique:users,email,' . $id,
            'mobile' => 'required|numeric|unique:users,mobile,' . $id,
            'password' => 'required|confirmed|min:6',
            'id' => 'required|numeric|not_in:0|exists:users,id'
        ];
        if ($id) {
            $rules['password'] = 'required_if:old_password,null|confirmed|min:6';
        }
        return match ($type) {
            'update' => Arr::only($rules, ['first_name', 'last_name', 'email', 'mobile', 'password', 'id']),
            'single' => Arr::only($rules, ['id']),
            default => $rules,
        };
    }

    #[Route('/super/profile/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(Request $request): void
    {
        $auth_user = Guard::check();
        $result = validate(['id' => $auth_user->id], $this->rules('single'));
        if (!empty($result)) {
            Redirect::internal('super/index');
        }
        $user = User::single($auth_user->id, $this->locale);

        $this->twig->display($this->view_folder.'_Authentication/profile/edit.html.twig',
            $request->get('forwards', []) + ['user' => $user]
        );
    }

    #[Route('/super/profile/update', methods: 'post')]
    public function update(Request $request): void
    {
        $auth_user = Guard::check();
        $id = $auth_user->id;

        $valid = csrfCheck('profile_edit');
        if (!$valid) {
            Redirect::internal('super/profile/edit');
        }

        $result = validate($request->all(), $this->rules('update', $id));
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->index($request);
            exit();
        }

        $image = IonUpload::update('stored_image', 'image_name',
            $request->file('image'), Path::files('users'));
        $image_return = $image->response();

        $params = [
            'id' => $request->get('id'),
            'email' => $request->get('email'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'mobile' => $request->get('mobile'),
            'mobile_2' => $request->get('mobile_2'),
            'password' => $request->get('password'),
            'address' => $request->get('address'),
            'notes' => $request->get('notes'),
            'image' => $image_return['store_name'] ?? null,
            'image_name' => $image_return['original_name'] ?? null,
        ];
        try {
            User::update((object)$params);

            $this->session->set('request_bag',
                ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_edit_message')]);

            Redirect::internal('super/profile');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->index($request);
            exit();
        }
    }
}
