<?php

namespace App\Http\super\Authentication;

use Carbon\Carbon;
use Ions\Auth\Guard\Role;
use Ions\Auth\Guard\User;
use Ions\Bundles\IonUpload;
use Ions\Bundles\Path;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Arr;
use Ions\Support\JsonResponse;
use Ions\Support\Request;
use Ions\Support\Route;
use JetBrains\PhpStorm\NoReturn;
use JetBrains\PhpStorm\Pure;
use Throwable;

class UserController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        $this->locale = appGetLocale();
        SharedData::accessApprove(['add' => 'save', 'edit' => 'update', 'index' => 'view','destroy' => 'destroyMulti']);
    }

    #[Pure] private function rules($type, $id = null): array
    {
        $rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'role_id' => 'required|numeric',
            'emails' => 'required|email|unique:users,email,' . $id,
            'mobile' => 'required|numeric|unique:users,mobile,' . $id,
            'password' => 'required|confirmed|min:6',
            'id' => 'required|numeric|not_in:0|exists:users,id',
            'ids' => 'required'
        ];
        if ($id) {
            $rules['password'] = 'required_if:old_password,null|confirmed|min:6';
        }
        return match ($type) {
            'store' => Arr::only($rules, ['first_name', 'last_name', 'role_id', 'email', 'mobile', 'password']),
            'update' => Arr::only($rules, ['first_name', 'last_name', 'role_id', 'email', 'mobile', 'password', 'id']),
            'single', 'delete' => Arr::only($rules, ['id']),
            'delete_multi' => Arr::only($rules, ['ids']),
            default => $rules,
        };
    }

    #[Route('/super/user/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {
        $users = User::all($this->locale);
        $users?->map(function ($user) {
            $user->check_box = $this->twig->render($this->view_folder.'_Authentication/user/show/checkbox.twig', ['id' => $user->id]);
            $user->created_at = Carbon::parse($user->created_at)->locale($this->locale)->isoFormat('LL');
            $user->actions = $this->twig->render($this->view_folder.'_Authentication/user/show/actions.twig', ['id' => $user->id]);
            return $user;
        });

        $this->twig->display($this->view_folder.'_Authentication/user/show.html.twig', ['users' => $users]);
    }

    #[Route('/super/user/add')]
    public function add(Request $request): void
    {
        $roles = Role::all($this->locale);

        $this->twig->display($this->view_folder.'_Authentication/user/add.html.twig',
            $request->get('forwards', []) + $request->all() + ['roles' => $roles]
        );
    }

    #[Route('/super/user/save', methods: 'post')]
    public function save(Request $request): void
    {
        $valid = csrfCheck('user_add');
        if (!$valid) {
            Redirect::internal('super/user/add');
        }

        $result = validate($request->all(), $this->rules('store'));
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->add($request);
            exit();
        }

        $image = IonUpload::store($request->file('image'), Path::files('users'))->response();

        $params = [
            'email' => $request->get('email'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'status' => $request->get('status'),
            'mobile' => $request->get('mobile'),
            'mobile_2' => $request->get('mobile_2'),
            'password' => $request->get('password'),
            'address' => $request->get('address'),
            'notes' => $request->get('notes'),
            'image' => $image['store_name'] ?? null,
            'image_name' => $image['original_name'] ?? null,
            'role_id' => $request->get('role_id')
        ];
        try {
            User::add((object)$params);

            $this->session->set('request_bag',
                ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_message')]);

            Redirect::internal('super/user');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->add($request);
            exit();
        }
    }

    #[Route('/super/user/view/{id}')]
    public function view(Request $request): void
    {
        $result = validate(['id' => $request->get('id')], $this->rules('single'));
        if (!empty($result)) {
            Redirect::internal('super/user');
        }

        $user = User::single($request->get('id'), $this->locale);
        $this->twig->display($this->view_folder.'_Authentication/user/view.html.twig', $request->all() + ['user' => $user]);
    }

    #[Route('/super/user/edit/{id}')]
    public function edit(Request $request): void
    {
        $result = validate(['id' => $request->get('id')], $this->rules('single'));
        if (!empty($result)) {
            Redirect::internal('super/user');
        }

        $roles = Role::all($this->locale);
        $user = User::single($request->get('id'), $this->locale);

        $this->twig->display($this->view_folder.'_Authentication/user/edit.html.twig',
            $request->get('forwards', []) + ['roles' => $roles, 'user' => $user]
        );
    }

    #[Route('/super/user/update', methods: 'post')]
    public function update(Request $request): void
    {
        $id = $request->get('id');

        $valid = csrfCheck('user_edit');
        if (!$valid) {
            Redirect::internal('super/user/edit/' . $id);
        }

        $result = validate($request->all(), $this->rules('update', $id));
        if (!empty($result)) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->edit($request);
            exit();
        }

        $image = IonUpload::update('stored_image', 'image_name',
            $request->file('image'), Path::files('users'));
        $image_return = $image->response();

        $params = [
            'id' => $request->get('id'),
            'email' => $request->get('email'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'status' => $request->get('status'),
            'mobile' => $request->get('mobile'),
            'mobile_2' => $request->get('mobile_2'),
            'password' => $request->get('password'),
            'address' => $request->get('address'),
            'notes' => $request->get('notes'),
            'image' => $image_return['store_name'] ?? null,
            'image_name' => $image_return['original_name'] ?? null,
            'role_id' => $request->get('role_id')
        ];
        try {
            User::update((object)$params);

            $this->session->set('request_bag',
                ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_edit_message')]);

            Redirect::internal('super/user');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->edit($request);
            exit();
        }
    }

    #[NoReturn] #[Route('/super/user/delete')]
    public function destroy(Request $request): void
    {
        $valid = csrfCheck('user_show');
        if (!$valid) {
            echo (new JsonResponse(['status' => false, 'message' => trans('messages_box.csrf_message')]))->getContent();
            exit();
        }
        $result = validate(['id' => $request->get('id')], $this->rules('delete'));
        if (!empty($result)) {
            echo (new JsonResponse(['status' => false, 'message' => $result]))->getContent();
            exit();
        }
        $id = $request->get('id');
        if (!User::delete($id)) {
            echo (new JsonResponse(['status' => false, 'message' => $id]))->getContent();
            exit();
        }
        echo (new JsonResponse(['status' => true, 'message' => '']))->getContent();
        exit();
    }

    #[NoReturn] #[Route('/super/user/deleteMulti')]
    public function destroyMulti(Request $request): void
    {
        $valid = csrfCheck('user_show');
        if (!$valid) {
            echo (new JsonResponse(['status' => false, 'message' => trans('messages_box.csrf_message')]))->getContent();
            exit();
        }

        $result = validate($request->all(), $this->rules('delete_multi'));
        if (!empty($result)) {
            echo (new JsonResponse(['status' => false, 'message' => $result]))->getContent();
            exit();
        }

        $ids = $request->get('ids');
        $result = User::deleteMulti($ids);
        if (count($result) > 0) {
            echo (new JsonResponse(['status' => false, 'message' =>
                (new JsonResponse($result))->getContent()
            ]))->getContent();
            exit();
        }

        echo (new JsonResponse(['status' => true, 'message' => '']))->getContent();
        exit();
    }
}
