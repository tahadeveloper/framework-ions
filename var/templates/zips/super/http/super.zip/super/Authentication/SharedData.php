<?php

namespace App\Http\super\Authentication;

use Ions\Auth\Guard\Control;
use Ions\Auth\Guard\Guard;
use Ions\Auth\Guard\Role;
use Ions\Auth\Guard\User;
use Ions\Bundles\Logs;
use Ions\Bundles\Redirect;
use Ions\Foundation\Kernel;
use Ions\Support\Arr;
use Ions\Support\JsonResponse;
use Naucon\Breadcrumbs\Breadcrumbs;

class SharedData
{
    /**
     * @param $template
     * @param array $options
     * @return void
     */
    public static function shared($template, array $options = []): void
    {
        if (!Guard::check()) {
            Redirect::internal('/super/logout');
        }

        $control_slug = $options['slug'] ?? (Kernel::request()->segment(2) ?? 'index');

        $current_language = appGetLocale();
        $login_user = Guard::check();
        $user_info = User::single($login_user->id);
        $shared = [
            'login_user' => $login_user,
            'full_access_permission' => $login_user->hasAccess('full_control'),
            'side_menu' => Role::hierarchy($user_info?->roles[0]->role_id,$current_language)//Control::hierarchy($current_language, [1])
        ];
        $template->addGlobal('share_vars', $shared);

        $control_data = Control::singleBySlug($control_slug, $current_language);
        if ($control_data) {
            $template->addGlobal('control_slug', $control_data->slug);
            $template->addGlobal('control_name', $control_data->language->name);
            $template->addGlobal('control_actives', $control_data->actives);
        }

        self::breadCrumbs($control_data, $template);

        if (Kernel::session()->has('request_bag')) {
            $template->addGlobal('request_bag',
                (new JsonResponse(Kernel::session()->get('request_bag')))->getContent()
            );
            Kernel::session()->remove('request_bag');
        }
    }

    /**
     * @param array $specialRules
     * @return void
     */
    public static function accessApprove(array $specialRules): void
    {
        $controlName = Kernel::request()->segment(1);
        $actionName = config('app._method');

        foreach ($specialRules as $ruleKey => $specialRule) {
            if (Arr::accessible($specialRule)) {
                if (in_array($actionName, $specialRule, true)) {
                    $actionName = (string)$ruleKey;
                }
            } else if ($actionName === $specialRule) {
                $actionName = (string)$ruleKey;
            }
        }

        $user = Guard::check();
        if ($user->hasAccess('full_control')) {
            Logs::create('super.log')->info('User(' . $user->first_name . ') have full access');
        }
        if (!$user->hasAccess('full_control')) {
            if (!$control = Control::singleBySlug($controlName)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/1');
            }

            if (!$action = Control::actionBySlug($actionName, $control->id)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/2');
            }

            if (!$user->hasAccess($control->id . '.' . $action->id)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/3');
            }
        }
    }

    /**
     * @param mixed $control_data
     * @param $template
     * @return void
     */
    public static function breadCrumbs(mixed $control_data, $template): void
    {
        $breadcrumbs = new Breadcrumbs();
        $segments = Kernel::request()->segments();

        $breadcrumbs->add(trans('titles.dashboard'), appUrl('/super/index'));
        $link = '';
        for ($i = 2, $iMax = count($segments); $i <= $iMax; $i++) {
            $link_name = Kernel::request()->segment($i);
            if (is_numeric($link_name)) {
                continue;
            }
            if (isset($control_data->slug) && Kernel::request()->segment($i) === $control_data->slug) {
                $link_name = 'show';
            }

            if ($i < $iMax & $i > 0) {
                $link .= "/super/" . Kernel::request()->segment($i);
                if ($link_name === 'edit' || $link_name === 'view') {
                    $breadcrumbs->add(trans('titles.' . $link_name));
                } else {
                    $breadcrumbs->add(trans('titles.' . $link_name), appUrl($link));
                }

            } else {
                $breadcrumbs->add(trans('titles.' . $link_name));
            }
        }

        $template->addGlobal('breadcrumbs', $breadcrumbs);
    }

}
