<?php

namespace App\Http\super\Authentication;


use Ions\Foundation\BaseController;
use Ions\Support\Request;
use Ions\Support\Route;

class ErrorController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
    }

    #[Route('/super/error/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {

        $this->twig->display($this->view_folder . '_Authentication/error/error-500.twig');
    }

    #[Route('/super/error/deny/{id}')]
    public function deny(Request $request): void
    {
        $id = $request->get('id');

        $this->twig->display($this->view_folder . '_Authentication/error/error-500.twig', ['deny_no' => $id]);
    }
}
