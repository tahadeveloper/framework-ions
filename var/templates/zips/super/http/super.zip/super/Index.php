<?php

namespace App\Http\super;

use App\Http\super\Auth\SharedData;
use Ions\Foundation\BaseController;
use Ions\Support\Request;
use Ions\Support\Route;

#[Route('/super')]
class Index extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
    }

    #[Route('/index')]
    public function index(Request $request): void
    {
        $this->twig->display($this->viewSpace . 'index.html.twig');
    }

}
