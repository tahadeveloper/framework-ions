<?php

namespace App\Http\super\Auth;

use Carbon\Carbon;
use Ions\Auth\Guard\GuardRole;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Arr;
use Ions\Support\Request;
use Ions\Support\Route;
use JetBrains\PhpStorm\NoReturn;
use JetBrains\PhpStorm\Pure;
use Throwable;

#[Route('/super')]
class Role extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        $this->locale = appGetLocale();
        SharedData::accessApprove(['add' => 'save', 'edit' => 'update', 'index' => 'view', 'destroy' => 'destroyMulti']);
    }

    #[Pure] private function rules($type, $id = null): array
    {
        $rules = [
            'slug' => 'required|unique:roles,slug,' . $id,
            'name_ar' => 'required',
            'name_en' => 'required',
            'id' => 'required|numeric|not_in:0|exists:roles,id',
            'ids' => 'required'
        ];
        return match ($type) {
            'store' => Arr::only($rules, ['slug', 'name_ar', 'name_en']),
            'update' => Arr::only($rules, ['slug', 'name_ar', 'name_en', 'id']),
            'single', 'delete' => Arr::only($rules, ['id']),
            'delete_multi' => Arr::only($rules, ['ids']),
            default => $rules,
        };
    }

    #[Route('/role/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {
        $roles = GuardRole::all($this->locale);
        $roles?->map(function ($role) {
            $role->check_box = $this->twig->render($this->viewSpace . '_Auth/role/show/checkbox.twig', ['id' => $role->id]);
            $role->updated_at = Carbon::parse($role->updated_at)->locale($this->locale)->isoFormat('LL');
            $role->created_at = Carbon::parse($role->created_at)->locale($this->locale)->isoFormat('LL');
            $role->actions = $this->twig->render($this->viewSpace . '_Auth/role/show/actions.twig', ['id' => $role->id]);
            return $role;
        });

        $this->twig->display($this->viewSpace . '_Auth/role/show.html.twig', ['roles' => $roles]);
    }

    #[Route('/role/add')]
    public function add(Request $request): void
    {
        $controls_tree = GuardRole::hierarchy(0, $this->locale);
        $this->twig->display($this->viewSpace . '_Auth/role/add.html.twig',
            $request->get('forwards', []) + $request->all() + ['controls_tree' => $controls_tree]
        );
    }

    #[Route('/role/save', methods: 'post')]
    public function save(Request $request): void
    {
        if (!csrfCheck('role_add')) {
            Redirect::internal('super/role/add');
        }

        if (!empty($result = validate($request->all(), $this->rules('store')))) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->add($request);
            exit();
        }

        $params = [
            'name' => $request->get('slug'),
            'slug' => $request->get('slug'),
            'languages' => [
                ['language_name' => 'ar', 'name' => $request->get('name_ar')],
                ['language_name' => 'en', 'name' => $request->get('name_en')],
            ]
        ];

        try {

            $role_id = GuardRole::add(toObject($params));

            $per_params = [
                'ids_controls' => $request->get('ids_controls'),
                'ids_actions' => $request->get('ids_actions'),
                'id' => $role_id
            ];
            GuardRole::permissions(toObject($per_params));
            $this->session->set('request_bag', ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_message')]);

            Redirect::internal('super/role');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->add($request);
        }
    }

    #[Route('/role/view/{id}')]
    public function view(Request $request): void
    {
        if (!empty(validate(['id' => $request->get('id')], $this->rules('single')))) {
            Redirect::internal('super/role');
        }

        $id = $request->get('id');
        $role = GuardRole::single($id, $this->locale);
        $controls_tree = GuardRole::hierarchy($id, $this->locale);

        $this->twig->display($this->viewSpace . '_Auth/role/view.html.twig', $request->all() +
            ['role' => $role, 'controls_tree' => $controls_tree]);
    }

    #[Route('/role/edit/{id}')]
    public function edit(Request $request): void
    {
        if (!empty(validate(['id' => $request->get('id')], $this->rules('single')))) {
            Redirect::internal('super/role');
        }

        $id = $request->get('id');
        $controls_tree = GuardRole::hierarchy($id, $this->locale);
        ray($controls_tree);
        $role = GuardRole::single($request->get('id'));

        $this->twig->display($this->viewSpace . '_Auth/role/edit.html.twig',
            $request->get('forwards', []) + ['role' => $role, 'controls_tree' => $controls_tree]
        );
    }

    #[Route('/role/update', methods: 'post')]
    public function update(Request $request): void
    {
        $id = $request->get('id');

        if (!csrfCheck('role_edit')) {
            Redirect::internal('super/role/edit/' . $id);
        }

        if (!empty($result = validate($request->all(), $this->rules('update', $id)))) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->edit($request);
            exit();
        }

        $params = [
            'id' => $id,
            'name' => $request->get('slug'),
            'slug' => $request->get('slug'),
            'languages' => [
                ['language_id' => $request->get('language_ar_id'), 'language_name' => 'ar', 'name' => $request->get('name_ar')],
                ['language_id' => $request->get('language_en_id'), 'language_name' => 'en', 'name' => $request->get('name_en')],
            ]
        ];
        try {
            GuardRole::update(toObject($params));

            $per_params = [
                'ids_controls' => $request->get('ids_controls'),
                'ids_actions' => $request->get('ids_actions'),
                'id' => $id
            ];
            GuardRole::permissions(toObject($per_params));
            $this->session->set('request_bag', ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_edit_message')]);

            Redirect::internal('super/role');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->add($request);
        }
    }

    #[NoReturn] #[Route('/role/delete')]
    public function destroy(Request $request): void
    {
        if (!csrfCheck('role_show')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        if (!empty($result = validate(['id' => $request->get('id')], $this->rules('delete')))) {
            display(toJson(['status' => false, 'message' => $result]));
        }

        $id = $request->get('id');
        if (!GuardRole::delete($id)) {
            display(toJson(['status' => false, 'message' => trans('messages_box.delete_error')]));
        }

        display(toJson(['status' => true, 'message' => '']));
    }

    #[NoReturn] #[Route('/role/deleteMulti')]
    public function destroyAll(Request $request): void
    {
        if (!csrfCheck('role_show')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        if (!empty($result = validate($request->all(), $this->rules('delete_multi')))) {
            display(toJson(['status' => false, 'message' => $result]));
        }

        $ids = $request->get('ids');
        if (!GuardRole::deleteMulti(explode(',', $ids))) {
            display(toJson(['status' => false, 'message' => trans('messages_box.delete_error')]));
        }

        display(toJson(['status' => true, 'message' => '']));
    }
}
