<?php

namespace App\Http\super\Auth;

use Ions\Auth\Guard\GuardControl;
use Ions\Auth\Guard\Guard;
use Ions\Auth\Guard\GuardRole;
use Ions\Bundles\Logs;
use Ions\Bundles\Redirect;
use Ions\Foundation\Kernel;
use Ions\Support\Arr;
use Ions\Support\JsonResponse;
use JetBrains\PhpStorm\Pure;
use Naucon\Breadcrumbs\Breadcrumbs;

class SharedData
{
    /**
     * @param $template
     * @param array $options
     * @return void
     */
    public static function shared($template, array $options = []): void
    {
        if (!Guard::check()) {
            Redirect::internal('super/logout');
        }

        $user_session = Kernel::session();

        if ($user_session->has('_super') && isset($user_session->get('_super')['_theme_style'])) {
            config()?->set('super.theme_style', $user_session->get('_super')['_theme_style']);
        }

        $control_slug = $options['slug'] ?? (Kernel::request()->segment(2) ?? 'index');

        $current_language = appGetLocale();
        $login_user = Guard::check();
        $role_info = GuardRole::single($login_user->roles[0]->id, $current_language);
        $shared = [
            'login_user' => $login_user,
            'login_role' => $role_info,
            'full_access_permission' => $login_user->hasAccess('full_control'),
            'side_menu' => GuardRole::hierarchy($login_user->roles[0]->id, $current_language)
        ];
        $template->addGlobal('share_vars', $shared);

        $control_data = GuardControl::singleBySlug($control_slug, $current_language);
        if ($control_data) {
            $template->addGlobal('control_slug', $control_data->slug);
            $template->addGlobal('control_name', $control_data->language->name);
            $template->addGlobal('control_actives', $control_data->actives);
        }

        self::breadCrumbs($control_data, $template);

        if ($user_session->has('request_bag')) {
            $template->addGlobal('request_bag',
                (new JsonResponse($user_session->get('request_bag')))->getContent()
            );
            $user_session->remove('request_bag');
        }
    }

    /**
     * @param array $specialRules
     * @return void
     */
    public static function accessApprove(array $specialRules): void
    {
        $controlName = Kernel::request()->attributes->get('_controller_name');
        $actionName = Kernel::request()->attributes->get('_method_name');

        $actionName = self::getActionName($specialRules, $actionName);

        $user = Guard::check();
        if ($user->hasAccess('full_control') && !config('app.app_debug')) {
            Logs::create('super.log')->info('User(' . $user->first_name . ') have full access',
                ['control' => $controlName, 'action' => $actionName]);
        }

        if (!$user->hasAccess('full_control')) {
            if (!$control = GuardControl::singleBySlug($controlName)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/1');
            }

            if (!$action = GuardControl::actionBySlug($actionName, $control->id)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/2');
            }

            if (!$user->hasAccess($control->id . '.' . $action->id)) {
                echo (new JsonResponse(['status' => false, 'message' => 'Access deny']))->getContent();
                Redirect::internal('super/error/deny/3');
            }
        }
    }

    /**
     * @param mixed $control_data
     * @param $template
     * @return void
     */
    public static function breadCrumbs(mixed $control_data, $template): void
    {
        $breadcrumbs = new Breadcrumbs();
        $segments = Kernel::request()->segments();

        $breadcrumbs->add(trans('titles.dashboard'), appUrl('/super/index'));
        $link = '';
        for ($i = 2, $iMax = count($segments); $i <= $iMax; $i++) {
            $link_name = Kernel::request()->segment($i);
            if (is_numeric($link_name)) {
                continue;
            }
            if (isset($control_data->slug) && Kernel::request()->segment($i) === $control_data->slug) {
                $link_name = 'show';
            }

            if ($i < $iMax & $i > 0) {
                $link .= "/super/" . Kernel::request()->segment($i);
                if ($link_name === 'edit' || $link_name === 'view') {
                    $breadcrumbs->add(trans('titles.' . $link_name));
                } else {
                    $breadcrumbs->add(trans('titles.' . $link_name), appUrl($link));
                }

            } else {
                $breadcrumbs->add(trans('titles.' . $link_name));
            }
        }

        $template->addGlobal('breadcrumbs', $breadcrumbs);
    }

    /**
     * @param array $specialRules
     * @param mixed $actionName
     * @return mixed|string
     */
    #[Pure] private static function getActionName(array $specialRules, mixed $actionName): mixed
    {
        foreach ($specialRules as $ruleKey => $specialRule) {
            if (Arr::accessible($specialRule)) {
                if (in_array($actionName, $specialRule, true)) {
                    $actionName = (string)$ruleKey;
                }
            } else if ($actionName === $specialRule) {
                $actionName = (string)$ruleKey;
            }
        }
        return $actionName;
    }

}
