<?php

namespace App\Http\super\Auth;

use Carbon\Carbon;
use Ions\Auth\Guard\GuardRole;
use Ions\Auth\Guard\GuardUser;
use Ions\Bundles\IonUpload;
use Ions\Bundles\Path;
use Ions\Bundles\Redirect;
use Ions\Foundation\BaseController;
use Ions\Support\Arr;
use Ions\Support\Request;
use Ions\Support\Route;
use JetBrains\PhpStorm\NoReturn;
use JetBrains\PhpStorm\Pure;
use Throwable;

#[Route('/super')]
class User extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        $this->locale = appGetLocale();
        SharedData::accessApprove(['add' => 'save', 'edit' => 'update', 'index' => 'view', 'destroy' => 'destroyMulti']);
    }

    #[Pure] private function rules($type, $id = null): array
    {
        $rules = [
            'first_name' => 'required',
            'last_name' => 'required',
            'role_id' => 'required|numeric',
            'emails' => 'required|email|unique:users,email,' . $id,
            'mobile' => 'required|numeric|unique:users,mobile,' . $id,
            'password' => 'required|confirmed|min:6',
            'id' => 'required|numeric|not_in:0|exists:users,id',
            'ids' => 'required'
        ];
        if ($id) {
            $rules['password'] = 'required_if:old_password,null|confirmed|min:6';
        }
        return match ($type) {
            'store' => Arr::only($rules, ['first_name', 'last_name', 'role_id', 'email', 'mobile', 'password']),
            'update' => Arr::only($rules, ['first_name', 'last_name', 'role_id', 'email', 'mobile', 'password', 'id']),
            'single', 'delete' => Arr::only($rules, ['id']),
            'delete_multi' => Arr::only($rules, ['ids']),
            default => $rules,
        };
    }

    #[Route('/user/{method}', requirements: ['method' => 'index'], defaults: ['method' => 'index'])]
    public function index(): void
    {
        $users = GuardUser::all($this->locale);
        $users?->map(function ($user) {
            $user->check_box = $this->twig->render($this->viewSpace . '_Auth/user/show/checkbox.twig', ['id' => $user->id]);
            $user->created_at = Carbon::parse($user->created_at)->locale($this->locale)->isoFormat('LL');
            $user->actions = $this->twig->render($this->viewSpace . '_Auth/user/show/actions.twig', ['id' => $user->id]);
            return $user;
        });

        $this->twig->display($this->viewSpace . '_Auth/user/show.html.twig', ['users' => $users]);
    }

    #[Route('/user/add')]
    public function add(Request $request): void
    {
        $roles = GuardRole::all($this->locale);

        $this->twig->display($this->viewSpace . '_Auth/user/add.html.twig',
            $request->get('forwards', []) + $request->all() + ['roles' => $roles]
        );
    }

    #[Route('/user/save', methods: 'post')]
    public function save(Request $request): void
    {
        if (!csrfCheck('user_add')) {
            Redirect::internal('super/user/add');
        }

        if (!empty($result = validate($request->all(), $this->rules('store')))) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->add($request);
            exit();
        }

        $image = IonUpload::store($request->file('image'), Path::files('users'))->response();

        $params = [
            'email' => $request->get('email'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'status' => $request->get('status'),
            'mobile' => $request->get('mobile'),
            'mobile_2' => $request->get('mobile_2'),
            'password' => $request->get('password'),
            'address' => $request->get('address'),
            'notes' => $request->get('notes'),
            'image' => $image['store_name'] ?? null,
            'image_name' => $image['original_name'] ?? null,
            'role_id' => $request->get('role_id')
        ];
        try {
            GuardUser::add(toObject($params));

            $this->session->set('request_bag',
                ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_message')]);

            Redirect::internal('super/user');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->add($request);
        }
    }

    #[Route('/user/view/{id}')]
    public function view(Request $request): void
    {
        if (!empty(validate(['id' => $request->get('id')], $this->rules('single')))) {
            Redirect::internal('super/user');
        }

        $user = GuardUser::single($request->get('id'), $this->locale);
        $this->twig->display($this->viewSpace . '_Auth/user/view.html.twig', $request->all() + ['user' => $user]);
    }

    #[Route('/user/edit/{id}')]
    public function edit(Request $request): void
    {
        if (!empty(validate(['id' => $request->get('id')], $this->rules('single')))) {
            Redirect::internal('super/user');
        }

        $roles = GuardRole::all($this->locale);
        $user = GuardUser::single($request->get('id'), $this->locale);

        $this->twig->display($this->viewSpace . '_Auth/user/edit.html.twig',
            $request->get('forwards', []) + ['roles' => $roles, 'user' => $user]
        );
    }

    #[Route('/user/update', methods: 'post')]
    public function update(Request $request): void
    {
        $id = $request->get('id');

        if (!csrfCheck('user_edit')) {
            Redirect::internal('super/user/edit/' . $id);
        }

        if (!empty($result = validate($request->all(), $this->rules('update', $id)))) {
            $request->attributes->set('forwards', ['error_message' => $result]);
            $this->edit($request);
            exit();
        }

        $image = IonUpload::update('stored_image', 'image_name',
            $request->file('image'), Path::files('users'));
        $image_return = $image->response();

        $params = [
            'id' => $request->get('id'),
            'email' => $request->get('email'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'status' => $request->get('status'),
            'mobile' => $request->get('mobile'),
            'mobile_2' => $request->get('mobile_2'),
            'password' => $request->get('password'),
            'address' => $request->get('address'),
            'notes' => $request->get('notes'),
            'image' => $image_return['store_name'] ?? null,
            'image_name' => $image_return['original_name'] ?? null,
            'role_id' => $request->get('role_id')
        ];
        try {
            GuardUser::update(toObject($params));

            $this->session->set('request_bag',
                ['status' => 'success', 'message' => trans('messages_box.inside_msg.success_edit_message')]);

            Redirect::internal('super/user');
        } catch (Throwable $e) {
            $request->attributes->set('forwards',
                ['error_message' => trans('messages_box.inside_msg.error.fail') . $e->getMessage()]);
            $this->edit($request);
        }
    }

    #[NoReturn] #[Route('/user/delete')]
    public function destroy(Request $request): void
    {
        if (!csrfCheck('user_show')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        if (!empty($result = validate(['id' => $request->get('id')], $this->rules('delete')))) {
            display(toJson(['status' => false, 'message' => $result]));
        }

        $id = $request->get('id');
        if (!GuardUser::delete($id)) {
            display(toJson(['status' => false, 'message' => trans('messages_box.delete_error')]));
        }

        display(toJson(['status' => true, 'message' => '']));
    }

    #[NoReturn] #[Route('/user/deleteMulti')]
    public function destroyAll(Request $request): void
    {
        if (!csrfCheck('user_show')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        if (!empty($result = validate($request->all(), $this->rules('delete_multi')))) {
            display(toJson(['status' => false, 'message' => $result]));
        }

        $ids = $request->get('ids');
        if (count(GuardUser::deleteMulti($ids)) > 0) {
            display(toJson(['status' => false, 'message' => trans('messages_box.delete_error')]));
        }

        display(toJson(['status' => true, 'message' => '']));
    }
}
