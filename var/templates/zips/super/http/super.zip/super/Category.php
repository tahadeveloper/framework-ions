<?php

namespace App\Http\super;

use App\Http\super\Auth\SharedData;
use App\Providers\CategoryProvider;
use Carbon\Carbon;
use Ions\Builders\DatatableQuery;
use Ions\Foundation\BaseController;
use Ions\Support\Request;
use JetBrains\PhpStorm\NoReturn;

class Category extends BaseController
{
    protected string $viewSpace = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        SharedData::accessApprove(['index' => ['view', 'render'],
            'add' => 'save', 'edit' => 'update', 'destroy' => 'destroyAll',
        ]);
    }

    public function index(): void
    {
        $columns = datatableCols(['check_box', 'id', 'name', 'email', 'created_at', 'updated_at', 'actions']);
        $this->twig->display($this->viewSpace . 'category/index.html.twig', ['columns' => $columns]);
    }

    public function render(Request $request): void
    {
        if ($request->ajax()) {
            $categories = CategoryProvider
                ::run(static fn() => $request->query->add((new DatatableQuery())->toQuery()))
                ->show()->toObject();
            $data = collect($categories->data->items)->map(function ($cat) {
                $cat->check_box = $this->twig->render($this->viewSpace . 'category/show/checkbox.twig', ['id' => $cat->id]);
                $cat->created_at = Carbon::parse($cat->created_at)->locale($this->locale)->isoFormat('LL');
                $cat->actions = $this->twig->render($this->viewSpace . 'category/show/actions.twig',
                    ['id' => $cat->id, 'control_slug' => 'category']);
                $cat->id = '<span class="badge badge-secondary">' . $cat->id . '</span>';
                return $cat;
            });

            $json_data = toJson([
                'recordsTotal' => $categories->data->total,
                'recordsFiltered' => $categories->data->total,
                'data' => $data,
            ]);
            echo $json_data;
       }
    }

    public function add(Request $request): void
    {
        // add form
    }

    public function save(Request $request): void
    {
        // submit add
    }

    public function view(Request $request): void
    {
        // show details
    }

    public function edit(Request $request): void
    {
        // edit form
    }

    public function update(Request $request): void
    {
        // submit edit
    }

    #[NoReturn]
    public function destroy(Request $request): void
    {
        if (!csrfCheck('csrf_token')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        $id = $request->get('id');
        $obj = CategoryProvider::delete($id)->toObject();
        if (!$obj->success) {
            display(toJson(['status' => false, 'message' => $obj->error], true));
        }

        display(toJson(['status' => true, 'message' => '']));
    }

    #[NoReturn]
    public function destroyAll(Request $request): void
    {
        if (!csrfCheck('csrf_token')) {
            display(toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]));
        }

        $ids = $request->get('ids');
        $obj = CategoryProvider::deleteAll(explode(',', $ids))->toObject();
        if (!$obj->success) {
            display(toJson(['status' => false, 'message' => $obj->error], true));
        }

        display(toJson(['status' => true, 'message' => '']));
    }

}