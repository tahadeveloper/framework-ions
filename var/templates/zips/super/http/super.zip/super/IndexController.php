<?php

namespace App\Http\super;

use App\Http\super\Authentication\SharedData;
use Ions\Foundation\BaseController;
use Ions\Support\Request;
use Ions\Support\Route;

class IndexController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
    }

    #[Route('/super/index')]
    public function index(Request $request): void
    {
        $this->twig->display($this->view_folder . 'index.html.twig');
    }

}
