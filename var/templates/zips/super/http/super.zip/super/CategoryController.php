<?php

namespace App\Http\super;

use App\Providers\CategoryProvider;
use Carbon\Carbon;
use Ions\Bundles\DatatableQuery;
use Ions\Foundation\BaseController;
use Ions\Support\JsonResponse;
use Ions\Support\Request;
use App\Http\super\Authentication\SharedData;
use JetBrains\PhpStorm\NoReturn;

class CategoryController extends BaseController
{
    protected string $view_folder = '@super/';
    protected string $locale_folder = 'super';

    public function _loadedState(Request $request): void
    {
        SharedData::shared($this->twig);
        SharedData::accessApprove(['add' => 'save', 'edit' => 'update', 'index' => 'view', 'destroy' => 'destroyMulti']);
    }

    public function index(): void
    {
        $columns = datatableCols(['check_box', 'id', 'name', 'email', 'created_at', 'updated_at', 'actions']);
        $this->twig->display($this->view_folder . 'category/index.html.twig', ['columns' => $columns]);

    }

    public function render(Request $request): void
    {
        if ($request->ajax()) {
            $categories = CategoryProvider
                ::run(static fn() => $request->query->add((new DatatableQuery())->toQuery()))
                ->show()->toObject();
            $data = collect($categories->data->items)->map(function ($cat) {
                $cat->check_box = $this->twig->render($this->view_folder . 'category/show/checkbox.twig', ['id' => $cat->id]);
                $cat->created_at = Carbon::parse($cat->created_at)->locale($this->locale)->isoFormat('LL');
                $cat->actions = $this->twig->render($this->view_folder . 'category/show/actions.twig',
                    ['id' => $cat->id, 'control_slug' => 'category']);
                $cat->id = '<span class="badge badge-secondary">' . $cat->id . '</span>';
                return $cat;
            });

            $json_data = toJson([
                'recordsTotal' => $categories->data->total,
                'recordsFiltered' => $categories->data->total,
                'data' => $data,
            ]);
            echo $json_data;
        }
    }

    public function add(Request $request): void
    {
        // add form
    }

    public function save(Request $request): void
    {
        // submit add
    }

    public function view(Request $request): void
    {
        // show details
    }

    public function edit(Request $request): void
    {
        // edit form
    }

    public function update(Request $request): void
    {
        // submit edit
    }

    #[NoReturn]
    public function destroy(Request $request): void
    {
        $valid = csrfCheck('csrf_token');
        if (!$valid) {
            echo toJson(['status' => false, 'message' => trans('messages_box.csrf_message')]);
            exit();
        }

        $id = $request->get('id');
        $obj = CategoryProvider::delete($id)->toObject();
        if (!$obj->success) {
            echo toJson(['status' => false, 'message' => $obj->error], true);
            exit();
        }

        echo toJson(['status' => true, 'message' => '']);

    }

    #[NoReturn]
    public function destroyAll(Request $request): void
    {
        $valid = csrfCheck('csrf_token');
        if (!$valid) {
            echo (new JsonResponse(['status' => false, 'message' => trans('messages_box.csrf_message')]))->getContent();
            exit();
        }

        $ids = $request->get('ids');
        $obj = CategoryProvider::deleteAll(explode(',', $ids))->toObject();
        if (!$obj->success) {
            echo toJson(['status' => false, 'message' => $obj->error], true);
            exit();
        }

        echo toJson(['status' => true, 'message' => '']);
        exit();
    }

}